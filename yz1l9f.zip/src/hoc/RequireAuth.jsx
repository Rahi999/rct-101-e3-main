import React from "react";

const RequiredAuth = ({ children }) => {
  return children;
};

export default RequiredAuth;